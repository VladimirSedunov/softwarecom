{
"base": {
    "logo": "notifications/softcompany.png",
    "project": "some project",
    "environment": "some env",
    "comment": "some comment",
    "reportLink": "https:\\reportLink",
    "language": "en",
    "allureFolder": "allure-report",
    "enableChart": true
  },
  "telegram": {
    "token": "6033667854:AAHjTayBxd3GGTb_Y4r2FAizwPvFba69OJA",
    "chat": "-924364276",
    "replyTo": ""
  }
}